import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;


public class Server {
    public static void main(String[] args) {
        
        if (args.length != 1) {
            System.err.println("Usage: java EchoServer <port number>");
            System.exit(1);
        }
         
        int portNumber = Integer.parseInt(args[0]);
        Server es = new Server();
        es.run(portNumber);
     }

     public void run(int portNumber) {
        try {
            ServerSocket serverSocket = new ServerSocket(portNumber);

            while(true) {
               Socket client = serverSocket.accept();
               Connection cc = new Connection(client);
            }
        } catch(Exception e) {
           System.out.println("Exception: "+e);
        }
    }

}

class Connection extends Thread {
	
    Socket client;
    PrintWriter out;
    BufferedReader in;
    DataInputStream br;
    DataOutputStream dos;
    
    public Connection(Socket s) { // constructor
       client = s;

       try {
           out = new PrintWriter(client.getOutputStream(), true);                   
           in = new BufferedReader(new InputStreamReader(client.getInputStream()));
       } catch (IOException e) {
           try {
             client.close();
           } catch (IOException ex) {
             System.out.println("Error while getting socket streams.."+ex);
           }
           return;
       }
        this.start(); // Thread starts here...this start() will call run()
    }
 
    public void run() {
      try {
            br = new DataInputStream(client.getInputStream());
            dos = new DataOutputStream(client.getOutputStream());

            FileWriter write = new FileWriter("temp.txt");

            //read amount
            int amount = br.readInt();
            String a = "(Received from: "+ client.getRemoteSocketAddress() + ") got amount as: "+amount;
            System.out.println(a);
            write.write(a); 

            //read interest
            double intrest = ((br.readDouble()/100)/12);
            String b = "(Received from: "+ client.getRemoteSocketAddress() + ") got intrest as: "+intrest;
            System.out.println(b);
            write.write(b);

            //read years
            int years = br.readInt()*12;
            String c = "(Received from: "+ client.getRemoteSocketAddress() + ") got years as: "+years;
            System.out.println(c);
            write.write(c);

            //mortgage formula
            double tophalf = amount * intrest * Math.pow((1 + intrest),years);
            double bottomhalf = Math.pow((1 + intrest),years) - 1;

            //output
            double Mpayment = tophalf/bottomhalf;

            

            String d = "The payment amount is: "+Mpayment+"\n";
            dos.writeBytes(d);
            write.write(d);

            //closing the writer
            write.close();

            System.out.println("I have sent the answer!");

            //send file to client
            //its up to the client whether they want the file but the server will send it anyways
            FileInputStream fr = new FileInputStream("temp.txt");
            byte []b1 = new byte [2000];
            fr.read(b1,0,b1.length);
            OutputStream os = client.getOutputStream();
            os.write(b1,0,b.length());
            os.close();
            fr.close();

            System.out.println("I have sent the file!");

            client.close();

       } catch (IOException e) {
           System.out.println("Exception caught...");
           System.out.println(e.getMessage());
       }
    }
}
