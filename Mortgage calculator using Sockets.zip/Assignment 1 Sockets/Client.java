import java.io.*;
import java.net.*;
import java.util.Scanner;
 

public class Client {
	 public static void main(String[] args ) throws Exception{
         
	        if (args.length != 2) {
	            System.err.println(
	                "Usage: java EchoClient <host name> <port number>");
	            System.exit(1);
	        }
	 
	        String hostName = args[0];
	        int portNumber = Integer.parseInt(args[1]);
	        
	        System.out.println("Connected at: "+java.time.LocalTime.now());  
	 
	        try {
	        	byte []b = new byte[2000];
	            Socket Client = new Socket(hostName, portNumber);
	            PrintWriter out = new PrintWriter(Client.getOutputStream(), true);
	            BufferedReader in = new BufferedReader(new InputStreamReader(Client.getInputStream()));
	            Scanner in1 = new Scanner(System.in);
	            DataInputStream br;
	            DataOutputStream dos;	            
	            
	            br = new DataInputStream(Client.getInputStream());
	            dos = new DataOutputStream(Client.getOutputStream());
	            
	            while(true) {
	            	
	            	//1st (Mortgage)

		            System.out.println("Welcome to the Mortgage Calculator");
		            
		            //ask for principal amount
		            System.out.println("What is your principal(total amount for mortgage)?");
		            int amount = in1.nextInt();
		            
		            //ask for interest rate
		            System.out.println("What is your interest rate?");
		            double intrest = in1.nextDouble();
		            
		            //ask for how many years they plan for paying
		            System.out.println("How many years of payment?");
		            int years = in1.nextInt();
		            
		            //send amount to server
		            dos.writeInt(amount);
		            dos.flush();
		            
		            //send interest to server
		            dos.writeDouble(intrest);
		            dos.flush();
		            
		            //send years to server
		            dos.writeInt(years);
		            dos.flush();
		            
		            //get the answer from the server
		            String answer = br.readLine();
		            System.out.println(answer);
		            
		            //2nd (for recieving and saving the file)
		            
		            System.out.println("Server has sent a file!");

		            System.out.println("would you like to save it to a file? ");
		            int input = in1.nextInt();
		            

		            if(input == 1){
		            	try {
		            		String name = "socketclient.txt";
		            		InputStream is = Client.getInputStream();
		            		FileOutputStream fr = new FileOutputStream(name);
		            		is.read(b,0, b.length);
		    	            fr.write(b,0,b.length);
		    	            fr.close();
		    	            is.close();
		            	}
		            	catch (IOException e) {
		            		e.printStackTrace();
		            	}
		            }
	            }

	        } catch (UnknownHostException e) {
	            System.err.println("Don't know about host " + hostName);
	            System.exit(1);
	        } catch (IOException e) {
	            System.err.println("Couldn't get I/O for the connection to " +
	                hostName);
	            System.exit(1);
	        } 
	    }

}
